import React, { useState } from 'react'
import {useSelector,useDispatch} from 'react-redux';
import { dangNhapAction } from '../../redux/actions/QuanLyNguoiDungActions';

//useSelector: thay thế mapStateToProps
//useDispatch: mapDispatchToProps (hoặc this.props.dispatch)


//Nơi khai báo các biến không cần thiết load lại khi setState (useState Hook)

export default function Login(props) {
//Nơi khai báo các biến hàm cần load lại mỗi khi thay đổi state, props
    let [state,setState] = useState({ 
                        taiKhoan: '', 
                        matKhau: '' 
                    });//Hook useState (giông thuộc tính state và phương thức setState)
    let dispatch = useDispatch(); //ứng với this.props.dispatch
    const propNguoidung = useSelector(state => state.QuanLyNguoiDungReducer.nguoiDung)
    console.log('newState',state);
    let handleChange = (event) =>{
        let {name,value} = event.target;
        setState({
            ...state,
            [name]:value
        })
    }

    let handleLogin = (event) => {
        event.preventDefault();
        //dispatch dữ liệu lên redux
        dispatch(dangNhapAction(state));
    }

    return (
        <div className="container">
            <h3>Đăng nhập</h3> <h3>{propNguoidung.taiKhoan}</h3>
            <form onSubmit={handleLogin}>
                <div className="form-group">
                    <span>Tài khoản</span>
                    <input name="taiKhoan" className="form-control" onChange={handleChange} />
                </div>
                <div className="form-group">
                    <span>Mật khẩu</span>
                    <input name="matKhau" className="form-control" onChange={handleChange}/>
                </div>
                <div className="form-group">
                    <button className="btn btn-success">Đăng nhập</button>
                </div>
            </form>
        </div>
    )
}
