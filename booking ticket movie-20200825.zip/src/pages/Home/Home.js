import React, { Component, useState, useEffect } from 'react'
import DrawerDemo from '../../components/Layout/DrawerDemo/DrawerDemo'
import Login from '../Login/Login'
import Axios from 'axios';
import { qlPhimService } from '../../services/QuanLyPhimService';
import { NavLink } from 'react-router-dom';

export default function Home(props) {

    //Khởi tạo state dsPhim
    let [dsPhim, setDSPhim] = useState([]);

    //Gọi api lấy danh sách phim từ server về
    useEffect(() => {
        //Callapi
        qlPhimService.layDanhSachPhim().then(res => {
            console.log('dsPhim', res.data);
            setDSPhim(res.data);
        }).catch(err => {
            console.log(err.response.data);
        })
    }, [])


    return (
        <div className="container">
            <h3 className="text-center">Danh sách phim</h3>
            <div className="row">
                {
                    dsPhim.map((phim, index) => {
                        return <div className="col-4" key={index}>
                            <div className="card text-left">
                                <img className="card-img-top" src={phim.hinhAnh} alt="123" />
                                <div className="card-body">
                                    <h4 className="card-title">{phim.tenPhim}</h4>
                                    <p className="card-text">{phim.moTa}</p>
                                    <NavLink to={`/detail/${phim.maPhim}`}>Chi tiết</NavLink>
                                    <button onClick={()=>{
                                        props.history.push(`/detail/${phim.maPhim}`)
                                    }} className="btn btn-success">Xem chi tiết</button>
                                </div>
                            </div>

                        </div>
                    })
                }
            </div>
        </div>
    )
}

