import React from 'react'

export default function Child(props) {
    return (
        <div>
            {props.children}
        </div>
    )
}
