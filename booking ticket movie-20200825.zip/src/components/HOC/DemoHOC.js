import React from 'react'
import Child from './Child'
import Modal from './Modal'
import Login from '../../pages/Login/Login'
import HOCModal from './ModalHOC';

let WrappedModal = HOCModal(Login,'Đăng nhập',function (){ alert('submitted')});


export default function DemoHOC() {
    return (
        <div>
            <button type="button" className="btn btn-primary btn-lg" data-toggle="modal" data-target="#modelId">
                Launch
            </button>
            <h3>Demo hoc</h3>
            <WrappedModal />
            {/* <Child>
                <div className="card text-left">
                    <img className="card-img-top" src="holder.js/100px180/" alt />
                    <div className="card-body">
                        <h4 className="card-title">Title</h4>
                        <p className="card-text">Body</p>
                    </div>
                </div>
            </Child>

            <Modal renderTitle={()=> {
                return <p style={{color:'red'}}>Login</p>
            }} 
           
            
            Component={Login}

            /> */}

       

        </div>
    )
}
