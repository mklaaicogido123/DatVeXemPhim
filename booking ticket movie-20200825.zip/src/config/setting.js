export const userLogin = 'userLogin';
export const accessToken = 'accessToken';
export const groupID = 'GP01'
export const domain = 'http://movie0706.cybersoft.edu.vn'
