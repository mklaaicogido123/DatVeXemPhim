export const dang_ky = 'dang_ky';
export const dang_nhap = 'dang_nhap';
