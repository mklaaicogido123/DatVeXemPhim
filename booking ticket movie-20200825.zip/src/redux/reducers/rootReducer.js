import {combineReducers} from 'redux';
import QuanLyNguoiDungReducer from './QuanLyNguoiDungReducer'



export const rootReducer = combineReducers({
    QuanLyNguoiDungReducer
})